

#хороший оттенок
x = input()
temp = x.lower()

if "хорош" in temp:
    print('YES', x)
else:
    print('NO', x)
